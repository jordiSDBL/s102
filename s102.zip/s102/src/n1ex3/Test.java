package n1ex3;

public class Test {
	public static void main(String[] args) {
		// inicialitzem array amb tres valors
		int[] numeros = { 2, 9, 1 };

		try {
			// recorrem l'array length + 1 per passar-nos del l�mit i for�ar l'error
			for (int i = 0; i < numeros.length + 1; i++) {
				System.out.println(numeros[i]);
			}
		} catch (Exception e) {
			// capturem i imprimir la pila d'excepcions
			e.printStackTrace(System.out);
		}
	}
}

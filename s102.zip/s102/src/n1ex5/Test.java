package n1ex5;

public class Test {
	public static void main(String[] args) {
		// inicialitzem array amb tres valors
		int divisio = 0;
		int num = 0;
		int i = 4;

		// gr�cies al while entra al catch "i" vegades
		while (num < i) {
			try {
				divisio = 10 / 0;
			} catch (Exception e) {
				System.out.println("Error: ");
				e.printStackTrace(System.out); // capturem i imprimir la pila d'excepcions
			}
			num++;
		}
		System.out.println("divisi�: " + divisio);
	}
}

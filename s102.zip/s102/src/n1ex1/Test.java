package n1ex1;

public class Test {
	public static void main(String[] args) {
		int resultat = 0;

		// M�tode try/catch per capturar excepci�
		try {
			resultat = divisio(10, 0);
		} catch (Exception e) {
			System.out.print("Entra al catch --> ");
			System.out.println(e.getMessage()); // missatge que ve propagat de la classe filla ExcepcioDivisio
		} finally {
			// s'executar� entri o no a try/catch
			System.out.print("Entra a finally --> ");
			
		}
		System.out.println("resultat: " + resultat);
	}

	//M�tode per definir a on es preveu que pugui donar problemes el programa.
	public static int divisio(int numerador, int denominador) throws ExcepcioDivisio {
		if (denominador == 0) {
			throw new ExcepcioDivisio("Error de divisi�.");
		}
		return numerador / denominador;
	}
}

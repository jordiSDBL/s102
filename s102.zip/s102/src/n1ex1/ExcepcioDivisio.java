package n1ex1;

@SuppressWarnings("serial")
public class ExcepcioDivisio extends Exception {
	public ExcepcioDivisio(String missatge) {
		super(missatge);
		/**
		 * Amb super, es propagar� el par�metre String missatge al constructor de la
		 * classe pare, que �s Exception.
		 */
	}
}

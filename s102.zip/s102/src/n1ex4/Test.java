package n1ex4;

public class Test {
	public static void main(String[] args) {
		String missatge = "buit";
		ExcepcioPropia ep = null; // objecte buit per for�ar l'entrada al catch

		try {
			missatge = cridaToString(ep);
			System.out.println(missatge);
		} catch (Exception e) {
			System.out.print("Entra al catch --> ");
			System.out.println(e.getMessage()); // segons enunciat: el m�tode que mostri la cadena de car�cters
												// emmagatzemada
		}
		System.out.println("missatge del toString() desat: " + missatge);
	}

	// M�tode per definir a on es preveu que pugui donar problemes el programa.
	public static String cridaToString(Object o) throws ExcepcioPropia {
		String missatge;

		if (o == null) {
			throw new ExcepcioPropia("L'objecte �s null, no es pot cridar al m�tode toString().");
		} else {
			missatge = o.toString();
		}

		return missatge;
	}
}

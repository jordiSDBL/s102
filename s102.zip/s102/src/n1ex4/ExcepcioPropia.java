package n1ex4;

@SuppressWarnings("serial")

public class ExcepcioPropia extends Exception {
	String missatge;

	public ExcepcioPropia(String missatge) {
		super(missatge);
		this.missatge = missatge; // segons enunciat: emmagatzemem l'argument com a atribut de la classe
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExcepcioPropia [missatge = ");
		builder.append(missatge);
		builder.append("]");
		return builder.toString();
	}
	
}

package n1ex2;

@SuppressWarnings("null")

public class Test {
	public static void main(String[] args) {
		// definim una refer�ncia a un objecte i l'inicialitzem a null
		Objecte o = null;
		// try/catch per capturar-ne l'excepci�
		try {
			System.out.println(o.toString());
		} catch (Exception e) {
			// e.printStackTrace(System.out); si es vol imprimir la pila d'excepcions
			// sencera
			System.out.println(e.getMessage()); // imprimir nom�s el missatge d'error
		}
	}
}

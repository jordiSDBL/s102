package n1ex2;

public class Objecte {
	// contructor
	public Objecte() {
	}

	// m�tode toString
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Objecte []");
		return builder.toString();
	}
}
